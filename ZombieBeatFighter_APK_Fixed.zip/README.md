# Zombie Beat Fighter

A fully offline Android rhythm-fighting game. Pick any song from your phone's
storage, the app analyzes its beat on-device, and zombies attack you in time
with the music. Tap when a zombie reaches the red line, in sync with the
beat, to kill it before it hits you.

**Everything runs offline at runtime.** No internet permission is used, no
cloud APIs, no ML model downloads — the beat detection is a self-contained
Kotlin algorithm (energy/onset peak-picking) that runs entirely on-device.
Internet is only needed once, while *building* the project, so Gradle can
download the Android build tools and two small AndroidX libraries.

## How to build the APK

1. Install **Android Studio** (free): https://developer.android.com/studio
2. Open Android Studio → **Open** → select this `ZombieBeatFighter` folder.
3. Let it sync (first sync needs internet, to download Gradle + AndroidX —
   after that the built app itself needs no internet at all).
4. Plug in your phone (with USB debugging on) or use an emulator, then:
   - **Run ▶** to install and launch directly, or
   - **Build → Build Bundle(s) / APK(s) → Build APK(s)** to get an
     installable `app-debug.apk` (Android Studio shows a "locate" link to
     find it in `app/build/outputs/apk/debug/`).
5. Copy that `.apk` to your phone and install it (allow "install from
   unknown sources" if prompted) if you didn't run it directly via USB.

## How to play

1. Launch the app → **Pick Song** → choose any song on your device.
2. Tap **Start Fight**. The app analyzes the track's beat (a few seconds for
   most songs, longer for very long files).
3. Zombies walk in from the right in one of 3 lanes, timed to arrive at the
   red line exactly on a beat. **Tap anywhere on the screen** right as a
   zombie crosses the line to kill it.
4. Miss too many and your health bar runs out. Survive the whole song to win.
   Score builds with combos for consecutive on-beat hits.

## How the beat detection works (`BeatDetector.kt`)

1. Decodes your song using Android's built-in `MediaExtractor`/`MediaCodec`
   (works with mp3, m4a/aac, wav, ogg — anything the device already supports
   natively, no extra libraries).
2. Downmixes to mono and streams it through ~23ms analysis windows.
3. Computes short-time energy per window and compares it against a rolling
   ~1 second local average.
4. Flags a "beat" whenever energy spikes well above that local average
   (a peak), with a minimum gap so one drum hit doesn't fire twice.

This is a lightweight, classic onset-detection approach — it works best on
songs with a clear, punchy beat (electronic, pop, rock, hip-hop). Very
ambient or beat-less tracks may produce a sparse or uneven rhythm.

## Tuning gameplay feel

Open `GameView.kt` and adjust:
- `hitToleranceMs` — how forgiving the timing window is (default 160ms)
- `travelDurationMs` — how long zombies take to walk in (default 1400ms)
- `damagePerMiss` / `scorePerHit` — difficulty/scoring balance

Open `BeatDetector.kt` and adjust:
- `SENSITIVITY` — lower = more beats detected (busier), higher = fewer,
  stronger beats only
- `MIN_BEAT_GAP_MS` — minimum time between detected beats

## Known limitations (first version)

- Beat detection is energy-based, not full BPM/tempo-grid tracking, so it
  follows the song's actual hits rather than a fixed metronome — this is
  intentional (works on any song without needing tempo metadata) but means
  very syncopated or quiet-intro tracks may feel uneven at first.
- No launcher icon set yet (uses the default Android icon) — easy to swap
  in Android Studio's Image Asset tool if you want custom art.
- Single character/zombie art is simple shapes, not sprites — a good next
  step if you want it to look more like a real game.
