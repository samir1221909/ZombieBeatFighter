package com.example.zombiebeatfighter

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Fully offline beat detector.
 *
 * Decodes whatever audio file the user picked (mp3, m4a, wav, ogg - anything
 * the device's built-in MediaCodec supports) into raw PCM using the on-device
 * decoder, then runs a streaming energy/onset analysis over the PCM to find
 * beat timestamps. No network, no cloud APIs, no ML model downloads.
 *
 * Algorithm (classic "energy peak" onset detection, good enough for dance/
 * rhythm-style beat tracking on arbitrary songs):
 *  1. Downmix to mono.
 *  2. Compute short-time energy (sum of squares) in ~23ms windows, 50% hop.
 *  3. Keep a rolling ~1s history of window energies to get a local average.
 *  4. A window is a "beat" if its energy is a local peak AND exceeds
 *     (localAverage * SENSITIVITY), with a minimum gap between beats so we
 *     don't fire multiple hits on the same drum hit.
 */
object BeatDetector {

    data class Result(val beatTimesMs: List<Long>, val durationMs: Long)

    private const val WINDOW_SIZE = 1024      // samples per analysis window
    private const val HOP_SIZE = 512          // 50% overlap
    private const val HISTORY_WINDOWS = 43    // ~1 second of history at 44.1kHz/512 hop
    private const val SENSITIVITY = 1.35f     // how far above local average counts as a beat
    private const val MIN_BEAT_GAP_MS = 220L  // don't allow beats closer than this (~270 BPM cap)

    fun detectBeats(
        context: Context,
        uri: Uri,
        onProgress: (Float) -> Unit
    ): Result {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)

        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                trackIndex = i
                format = f
                break
            }
        }
        if (trackIndex == -1 || format == null) {
            extractor.release()
            throw IllegalStateException("No audio track found in the selected file.")
        }
        extractor.selectTrack(trackIndex)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val channelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val durationMs = if (format.containsKey(MediaFormat.KEY_DURATION))
            format.getLong(MediaFormat.KEY_DURATION) / 1000 else 0L

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val beatTimes = ArrayList<Long>()

        // Streaming energy history (circular)
        val energyHistory = FloatArray(HISTORY_WINDOWS)
        var historyFilled = 0
        var historyPos = 0
        var lastBeatTimeMs = -10_000L

        // Leftover mono samples that didn't fill a full window yet
        var pending = FloatArray(0)
        var totalSamplesConsumed = 0L // mono sample index, for time calc

        val bufferInfo = MediaCodec.BufferInfo()
        var sawInputEOS = false
        var sawOutputEOS = false
        val timeoutUs = 10_000L

        fun processMonoChunk(mono: FloatArray) {
            // Combine leftover + new samples
            val combined: FloatArray
            if (pending.isNotEmpty()) {
                combined = FloatArray(pending.size + mono.size)
                System.arraycopy(pending, 0, combined, 0, pending.size)
                System.arraycopy(mono, 0, combined, pending.size, mono.size)
            } else {
                combined = mono
            }

            var start = 0
            while (start + WINDOW_SIZE <= combined.size) {
                var sumSq = 0f
                for (i in start until start + WINDOW_SIZE) {
                    val s = combined[i]
                    sumSq += s * s
                }
                val energy = sumSq / WINDOW_SIZE

                // Local average from history
                var avg = 0f
                if (historyFilled > 0) {
                    var sum = 0f
                    for (i in 0 until historyFilled) sum += energyHistory[i]
                    avg = sum / historyFilled
                }

                val windowCenterSample = totalSamplesConsumed + start + WINDOW_SIZE / 2
                val timeMs = (windowCenterSample * 1000L) / sampleRate

                if (historyFilled >= HISTORY_WINDOWS / 2 &&
                    energy > avg * SENSITIVITY &&
                    energy > 0.0003f &&
                    (timeMs - lastBeatTimeMs) >= MIN_BEAT_GAP_MS
                ) {
                    beatTimes.add(timeMs)
                    lastBeatTimeMs = timeMs
                }

                // push energy into circular history
                energyHistory[historyPos] = energy
                historyPos = (historyPos + 1) % HISTORY_WINDOWS
                if (historyFilled < HISTORY_WINDOWS) historyFilled++

                start += HOP_SIZE
            }

            totalSamplesConsumed += start
            pending = if (start < combined.size) {
                combined.copyOfRange(start, combined.size)
            } else {
                FloatArray(0)
            }
        }

        val totalDurationUs = if (durationMs > 0) durationMs * 1000 else 1L

        while (!sawOutputEOS) {
            if (!sawInputEOS) {
                val inIndex = codec.dequeueInputBuffer(timeoutUs)
                if (inIndex >= 0) {
                    val inBuffer: ByteBuffer = codec.getInputBuffer(inIndex)!!
                    val sampleSize = extractor.readSampleData(inBuffer, 0)
                    if (sampleSize < 0) {
                        codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        sawInputEOS = true
                    } else {
                        val presentationTimeUs = extractor.sampleTime
                        codec.queueInputBuffer(inIndex, 0, sampleSize, presentationTimeUs, 0)
                        extractor.advance()
                        if (durationMs > 0) {
                            val progress = (presentationTimeUs.toFloat() / totalDurationUs).coerceIn(0f, 1f)
                            onProgress(progress * 0.9f) // reserve last 10% for finalize
                        }
                    }
                }
            }

            val outIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            if (outIndex >= 0) {
                val outBuffer: ByteBuffer = codec.getOutputBuffer(outIndex)!!
                if (bufferInfo.size > 0) {
                    outBuffer.order(ByteOrder.LITTLE_ENDIAN)
                    outBuffer.position(bufferInfo.offset)
                    outBuffer.limit(bufferInfo.offset + bufferInfo.size)

                    val shortCount = bufferInfo.size / 2
                    val samples = ShortArray(shortCount)
                    var i = 0
                    while (outBuffer.remaining() >= 2 && i < shortCount) {
                        samples[i] = outBuffer.short
                        i++
                    }

                    // Downmix interleaved channels to mono float [-1, 1]
                    val mono = if (channelCount <= 1) {
                        FloatArray(shortCount) { samples[it] / 32768f }
                    } else {
                        val frames = shortCount / channelCount
                        FloatArray(frames) { f ->
                            var sum = 0f
                            for (c in 0 until channelCount) {
                                sum += samples[f * channelCount + c] / 32768f
                            }
                            sum / channelCount
                        }
                    }
                    processMonoChunk(mono)
                }
                codec.releaseOutputBuffer(outIndex, false)
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    sawOutputEOS = true
                }
            }
        }

        onProgress(1f)
        codec.stop()
        codec.release()
        extractor.release()

        val finalDurationMs = if (durationMs > 0) durationMs
        else (totalSamplesConsumed * 1000L) / sampleRate

        return Result(beatTimes, finalDurationMs)
    }
}
