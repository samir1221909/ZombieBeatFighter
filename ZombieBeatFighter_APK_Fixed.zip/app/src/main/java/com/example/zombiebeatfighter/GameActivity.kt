package com.example.zombiebeatfighter

import android.app.AlertDialog
import android.net.Uri
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class GameActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_SONG_URI = "extra_song_uri"
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var mediaPlayer: MediaPlayer? = null
    private var gameView: GameView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        val uri: Uri = intent.getParcelableExtra(EXTRA_SONG_URI)
            ?: run { finish(); return }

        val progressBar = findViewById<ProgressBar>(R.id.analyzingProgress)
        val analyzingLayout = findViewById<ViewGroup>(R.id.analyzingLayout)
        val gameContainer = findViewById<FrameLayout>(R.id.gameContainer)

        Thread {
            try {
                val result = BeatDetector.detectBeats(applicationContext, uri) { progress ->
                    mainHandler.post { progressBar.progress = (progress * 100).toInt() }
                }
                mainHandler.post {
                    startGame(uri, result, analyzingLayout, gameContainer)
                }
            } catch (e: Exception) {
                mainHandler.post {
                    findViewById<TextView>(R.id.analyzingText).text =
                        "Couldn't analyze this file: ${e.message}"
                }
            }
        }.start()
    }

    private fun startGame(
        uri: Uri,
        result: BeatDetector.Result,
        analyzingLayout: ViewGroup,
        gameContainer: FrameLayout
    ) {
        if (result.beatTimesMs.size < 4) {
            findViewById<TextView>(R.id.analyzingText).text =
                "Couldn't find a clear beat in this track. Try a song with a stronger drum/bass line."
            return
        }

        val player = MediaPlayer()
        mediaPlayer = player
        player.setDataSource(applicationContext, uri)
        player.prepare()

        val view = GameView(this, result.beatTimesMs, player) { won, score ->
            onGameOver(won, score)
        }
        gameView = view
        gameContainer.addView(
            view,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        analyzingLayout.visibility = ViewGroup.GONE
        gameContainer.visibility = ViewGroup.VISIBLE

        player.start()
    }

    private fun onGameOver(won: Boolean, score: Int) {
        mediaPlayer?.let { if (it.isPlaying) it.stop() }
        val title = if (won) "Survived!" else "You Died"
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("Score: $score")
            .setCancelable(false)
            .setPositiveButton("Retry") { _, _ -> recreate() }
            .setNegativeButton("Back") { _, _ -> finish() }
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
