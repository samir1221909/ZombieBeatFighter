package com.example.zombiebeatfighter

import android.content.Context
import android.graphics.*
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.*
import kotlin.random.Random

/**
 * GPU-friendly custom Canvas renderer. Everything is procedurally drawn so the
 * project stays tiny and offline while still looking much closer to a game.
 */
class GameView(
    context: Context,
    private val beatTimesMs: List<Long>,
    private val mediaPlayer: android.media.MediaPlayer,
    private val onGameOver: (won: Boolean, score: Int) -> Unit
) : View(context), Choreographer.FrameCallback {

    private val travelDurationMs = 1450L
    private val hitToleranceMs = 155L
    private val damagePerMiss = 12
    private val scorePerHit = 100
    private val laneCount = 3

    private data class Zombie(val hitTimeMs: Long, val spawnTimeMs: Long, val lane: Int, val move: Int, var alive: Boolean = true, var resolved: Boolean = false)
    private data class Burst(val x: Float, val y: Float, val born: Long, val good: Boolean)

    private val zombies = ArrayList<Zombie>(32)
    private val bursts = ArrayList<Burst>(32)
    private var nextBeatIndex = 0
    private var health = 100
    private var score = 0
    private var combo = 0
    private var bestCombo = 0
    private var gameEnded = false
    private var lastFrame = 0L
    private var beatPulse = 0f
    private var shake = 0f
    private var flash = 0f
    private var flashColor = Color.WHITE
    private var lastMoveName = "READY"
    private var moveHint = "HIT ON THE BEAT"

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rng = Random(42)
    private val stars = Array(42) { Pair(rng.nextFloat(), rng.nextFloat()) }

    init {
        isFocusable = true
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!gameEnded) {
            update()
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun now() = try { mediaPlayer.currentPosition.toLong() } catch (_: Exception) { 0L }

    private fun update() {
        val t = now()
        if (lastFrame == 0L) lastFrame = t
        beatPulse *= 0.82f
        shake *= 0.82f
        flash *= 0.86f

        while (nextBeatIndex < beatTimesMs.size) {
            val hit = beatTimesMs[nextBeatIndex]
            if (t < hit - travelDurationMs) break
            val move = nextBeatIndex % 5
            zombies.add(Zombie(hit, hit - travelDurationMs, nextBeatIndex % laneCount, move))
            nextBeatIndex++
        }

        for (z in zombies) {
            if (!z.alive || z.resolved) continue
            if (t > z.hitTimeMs + hitToleranceMs) {
                z.resolved = true; z.alive = false
                health = (health - damagePerMiss).coerceAtLeast(0)
                combo = 0
                moveHint = "MISS"
                flashColor = Color.rgb(255, 55, 75); flash = 0.30f; shake = 10f
            }
        }
        zombies.removeAll { it.resolved && !it.alive }
        bursts.removeAll { t - it.born > 420L }

        if (health <= 0) endGame(false)
        if (!mediaPlayer.isPlaying && nextBeatIndex >= beatTimesMs.size && zombies.isEmpty() && !gameEnded) endGame(true)
        lastFrame = t
    }

    private fun endGame(won: Boolean) {
        if (gameEnded) return
        gameEnded = true
        onGameOver(won, score)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_DOWN || gameEnded) return true
        val t = now()
        var best: Zombie? = null
        var diff = Long.MAX_VALUE
        for (z in zombies) if (z.alive && !z.resolved) {
            val d = abs(z.hitTimeMs - t)
            if (d < diff) { diff = d; best = z }
        }
        if (best != null && diff <= hitToleranceMs) {
            best!!.alive = false; best!!.resolved = true
            combo++; bestCombo = max(bestCombo, combo)
            val quality = when { diff <= 55 -> 3; diff <= 105 -> 2; else -> 1 }
            score += scorePerHit * quality + combo * 5
            lastMoveName = arrayOf("LEFT PUNCH", "RIGHT PUNCH", "KICK", "BLOCK", "SPECIAL")[best!!.move]
            moveHint = when (quality) { 3 -> "PERFECT"; 2 -> "GOOD"; else -> "HIT" }
            flashColor = if (quality == 3) Color.rgb(70, 255, 210) else Color.rgb(255, 190, 70)
            flash = if (quality == 3) .20f else .12f
            shake = if (quality == 3) 9f else 5f
            bursts.add(Burst(width * .20f, laneY(best!!.lane), t, quality == 3))
            beatPulse = 1f
        } else {
            combo = 0; moveHint = "TOO EARLY"
        }
        return true
    }

    private fun laneY(lane: Int): Float = height * .34f + lane * height * .16f

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat(); val t = now()
        c.drawColor(Color.rgb(7, 8, 16))

        val dx = (sin(t * .03) * shake).toFloat()
        c.save(); c.translate(dx, 0f)
        drawBackdrop(c, w, h, t)
        drawHud(c, w, h)
        drawArena(c, w, h, t)
        drawZombies(c, w, h, t)
        drawPlayer(c, w, h, t)
        drawBursts(c, t)
        c.restore()

        if (flash > .01f) {
            fill.color = flashColor; fill.alpha = (flash * 255).toInt().coerceIn(0, 90)
            c.drawRect(0f, 0f, w, h, fill); fill.alpha = 255
        }
    }

    private fun drawBackdrop(c: Canvas, w: Float, h: Float, t: Long) {
        bg.shader = LinearGradient(0f, 0f, 0f, h, Color.rgb(17, 14, 35), Color.rgb(4, 12, 20), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, bg); bg.shader = null
        fill.color = Color.WHITE
        for ((x, y) in stars) { fill.alpha = (70 + 70 * abs(sin(t * .001 + x * 9))).toInt(); c.drawCircle(x*w, y*h*.55f, 1.4f, fill) }
        fill.alpha = 255
        // city silhouette
        fill.color = Color.rgb(12, 18, 28)
        for (i in 0..13) { val bw = w/14f; val bh = h*(.10f + ((i*37)%8)*.012f); c.drawRect(i*bw, h*.70f-bh, i*bw+bw-3, h*.70f, fill) }
        // horizon glow
        bg.shader = RadialGradient(w*.52f, h*.62f, w*.7f, intArrayOf(Color.argb(80,70,180,255), Color.TRANSPARENT), floatArrayOf(0f,1f), Shader.TileMode.CLAMP)
        c.drawRect(0f,h*.35f,w,h*.8f,bg); bg.shader=null
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        text.color = Color.WHITE; text.textSize = 24f
        c.drawText("SCORE  $score", 24f, 38f, text)
        text.textSize = 18f; text.color = Color.rgb(190,205,225)
        c.drawText("BEST COMBO  x$bestCombo", 24f, 63f, text)
        // health
        fill.color = Color.argb(100,255,255,255); c.drawRoundRect(w-190f,22f,w-24f,36f,7f,7f,fill)
        fill.color = Color.rgb(70,235,160); c.drawRoundRect(w-190f,22f,w-190f+166f*(health/100f),36f,7f,7f,fill)
        small.textSize=14f; small.color=Color.WHITE; c.drawText("HP",w-218f,34f,small)
    }

    private fun drawArena(c: Canvas, w: Float, h: Float, t: Long) {
        val top=h*.30f; val bottom=h*.78f
        stroke.strokeWidth=2f; stroke.color=Color.argb(55,110,220,255)
        for (i in 0..laneCount) c.drawLine(0f, top+i*(bottom-top)/laneCount,w,top+i*(bottom-top)/laneCount,stroke)
        // hit rail
        val x=w*.20f; stroke.strokeWidth=5f; stroke.color=Color.rgb(255,70,100); c.drawLine(x,top,x,bottom,stroke)
        stroke.strokeWidth=2f; stroke.color=Color.argb(120,255,70,100); c.drawLine(x-7,top,x-7,bottom,stroke)
        // pulse ring
        if (beatPulse>.02f) { stroke.strokeWidth=3f; stroke.color=Color.argb((beatPulse*180).toInt(),70,255,220); c.drawCircle(x,bottom*.62f,55f+beatPulse*25f,stroke) }
        small.textSize=12f; small.color=Color.rgb(255,100,125); c.drawText("BEAT",x-22f,top-12f,small)
        // move prompt
        fill.color=Color.argb(170,10,15,25); c.drawRoundRect(w*.32f, h*.12f, w*.80f,h*.23f,18f,18f,fill)
        text.textSize=22f; text.color=Color.WHITE; text.textAlign=Paint.Align.CENTER; c.drawText(lastMoveName,w*.56f,h*.165f,text)
        small.textSize=13f; small.color=Color.rgb(90,255,210); c.drawText(moveHint,w*.56f,h*.205f,small); text.textAlign=Paint.Align.LEFT
    }

    private fun drawZombies(c: Canvas,w:Float,h:Float,t:Long) {
        val top=h*.30f; val laneH=(h*.48f)/laneCount; val xHit=w*.20f
        for (z in zombies) if (z.alive) {
            val p=((t-z.spawnTimeMs).toFloat()/(z.hitTimeMs-z.spawnTimeMs)).coerceIn(0f,1.12f)
            val x=w-p*(w-xHit); val y=top+z.lane*laneH+laneH/2f
            val s=1f+.08f*p
            c.save(); c.translate(x,y); c.scale(s,s)
            // shadow
            fill.color=Color.argb(100,0,0,0); c.drawOval(-38f,34f,38f,48f,fill)
            // glow
            glow.color=Color.argb(55,80,255,170); c.drawCircle(0f,0f,48f,glow)
            // body
            fill.color=Color.rgb(83,170,112); c.drawRoundRect(-23f,-5f,23f,39f,12f,12f,fill)
            fill.color=Color.rgb(116,205,135); c.drawCircle(0f,-30f,22f,fill)
            // hair
            fill.color=Color.rgb(30,45,38); c.drawArc(-24f,-52f,24f,-15f,180f,180f,true,fill)
            // eyes
            fill.color=Color.rgb(255,80,95); c.drawCircle(-8f,-31f,4f,fill); c.drawCircle(8f,-31f,4f,fill)
            // arms
            stroke.strokeWidth=9f; stroke.color=Color.rgb(83,170,112); c.drawLine(-19f,5f,-38f,24f,stroke); c.drawLine(19f,5f,38f,24f,stroke)
            // legs
            c.drawLine(-10f,36f,-17f,62f,stroke); c.drawLine(10f,36f,17f,62f,stroke)
            c.restore()
        }
    }

    private fun drawPlayer(c: Canvas,w:Float,h:Float,t:Long) {
        val x=w*.20f; val y=h*.61f
        val active=beatPulse
        c.save(); c.translate(x,y); c.scale(1.0f+active*.035f,1.0f+active*.035f)
        // aura
        glow.color=Color.argb((35+active*80).toInt(),70,220,255); c.drawCircle(0f,0f,70f+active*10f,glow)
        // legs/body/head
        fill.color=Color.rgb(55,65,92); c.drawRoundRect(-24f,-5f,24f,55f,12f,12f,fill)
        fill.color=Color.rgb(235,194,158); c.drawCircle(0f,-32f,21f,fill)
        fill.color=Color.rgb(20,23,35); c.drawArc(-23f,-55f,23f,-18f,180f,180f,true,fill)
        stroke.strokeWidth=10f; stroke.color=Color.rgb(70,220,220)
        // pose cycles from the beat/move
        val phase=lastMoveName
        when(phase) {
            "LEFT PUNCH" -> c.drawLine(-17f,7f,-65f,-8f,stroke)
            "RIGHT PUNCH" -> c.drawLine(17f,7f,65f,-8f,stroke)
            "KICK" -> c.drawLine(14f,48f,63f,34f,stroke)
            "BLOCK" -> { c.drawLine(-18f,4f,-42f,-28f,stroke); c.drawLine(18f,4f,42f,-28f,stroke) }
            "SPECIAL" -> { c.drawCircle(0f,5f,44f,stroke); c.drawLine(-22f,25f,-48f,52f,stroke); c.drawLine(22f,25f,48f,52f,stroke) }
            else -> { c.drawLine(-18f,6f,-36f,28f,stroke); c.drawLine(18f,6f,36f,28f,stroke) }
        }
        c.drawLine(-10f,50f,-18f,76f,stroke); c.drawLine(10f,50f,18f,76f,stroke)
        c.restore()
    }

    private fun drawBursts(c:Canvas,t:Long) {
        for (b in bursts) {
            val p=((t-b.born)/420f).coerceIn(0f,1f); val r=20f+p*70f
            stroke.strokeWidth=4f; stroke.color=Color.argb(((1f-p)*220).toInt(), if(b.good)70 else 255, if(b.good)255 else 170, if(b.good)210 else 70)
            c.drawCircle(b.x,b.y,r,stroke)
            small.textAlign=Paint.Align.CENTER; small.textSize=22f; small.color=stroke.color
            c.drawText(if(b.good)"PERFECT" else "HIT",b.x,b.y-80f*p,small); small.textAlign=Paint.Align.LEFT
        }
    }
}
