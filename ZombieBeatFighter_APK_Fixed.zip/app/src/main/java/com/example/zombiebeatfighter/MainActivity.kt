package com.example.zombiebeatfighter

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var selectedSongUri: Uri? = null

    private val pickSongLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: SecurityException) {
                    // Some providers don't support persistable permissions; ignore,
                    // the Uri is still usable for this session.
                }
                selectedSongUri = uri
                findViewById<TextView>(R.id.selectedSongText).text =
                    "Selected: " + getFileName(uri)
                findViewById<Button>(R.id.startButton).isEnabled = true
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.pickSongButton).setOnClickListener {
            pickSongLauncher.launch(arrayOf("audio/*"))
        }

        findViewById<Button>(R.id.startButton).setOnClickListener {
            val uri = selectedSongUri ?: return@setOnClickListener
            val intent = Intent(this, GameActivity::class.java)
            intent.putExtra(GameActivity.EXTRA_SONG_URI, uri)
            startActivity(intent)
        }
    }

    private fun getFileName(uri: Uri): String {
        var name = "song"
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = it.getString(idx)
            }
        }
        return name
    }
}
